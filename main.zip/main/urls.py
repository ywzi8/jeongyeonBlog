from django.contrib import admin
from django.urls import path
from main.views import index, blog, posting, new_postin, delete_posting,edit_post,update_post, edit_post_view

from django.conf.urls.static import static
from django.conf import settings


urlpatterns = [
    path('admin/',admin.site.urls),
    path('',index, name='index'),
    path('blog/',blog, name='blog'),
    path('blog/<int:pk>', posting, name='posting'),
    path('blog/new_postin/',new_postin, name='new_postin'),
    path('blog/<int:pk>/remove/', delete_posting, name="delete_posting"),
    path('blog/<int:pk>/edit/',edit_post, name='edit_post'),
    path('blog/<int:pk>/update/', update_post, name='update_post'),
    path('blog/<int:pk>/edit/', edit_post_view, name='edit_post'),
]

urlpatterns += static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)

from django.shortcuts import render, get_object_or_404
from django.shortcuts import redirect
from . models import Post
from . forms import PostForm


# Create your views here.
def index(request):
    return render(request, 'main/index.html')

def blog(request):
    postlist = Post.objects.all()
    return render(request, 'main/blog.html', {'postlist':postlist})

def posting(request, pk):
    post = Post.objects.get(pk=pk)
    return render(request, 'main/posting.html',{'post':post})

def new_postin(request):
    if request.method == "POST":
        if request.POST['photo']:
            new_article = Post.objects.create(
                postTitle = request.POST['postTitle'],
                pub_date = request.POST['pub_date'],
                photo = request.POST['photo'],
                contents = request.POST['contents'],
            )
        else:
            new_article = Post.objects.create(
                postTitle = request.POST['postTitle'],
                pub_date = request.POST['pub_date'],
                photo = request.POST['photo'],
                contents = request.POST['contents'],
            )
        return redirect('/blog/')
    return render(request, 'main/new_postin.html')


def delete_posting(request, pk):
    post = Post.objects.get(pk=pk)
    if request.method == 'POST':
        post.delete()
        return redirect('/blog/')
    return render(request, 'main/delete_posting.html',{'Post': post})

def edit_post(request, pk):
    post = get_object_or_404(Post, pk=pk)
    form = PostForm(instance=post)
    return render(request, 'edit_post.html', {'form':form, 'post':post})

def update_post(request, pk):
    post = get_object_or_404(Post, pk=pk)

    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES, instance=post)
        if form.is_valid():
            form.save()
            return redirect('posting', pk=post.pk)
        
    else:
        form = PostForm(instance=post)
    
    return render(request, 'edit_post.html',{'form':form,'post':post})
def edit_post_view(request, pk):
    post = get_object_or_404(Post, pk=pk)
    return render(request, 'edit_post.html', {'post': post})


    
    




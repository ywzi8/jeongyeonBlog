from django.db import models

# Create your models here)
# 게시글 제목(postTitle), 작성시간(pub_date), 내용(contents)
class Post(models.Model):
    postTitle = models.CharField(max_length=50)
    pub_date = models.DateTimeField('date published')

    photo = models.ImageField(blank = True, null = True)
    contents = models.TextField()

    def __str__(self):
        return self.postTitle

